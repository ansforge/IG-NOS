# ANS.FR.NOS\Mapping NOS to FHIR - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**NOS**](nos.md)
* **Mapping NOS to FHIR**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Mapping NOS to FHIR

`DRAFT au 28/08/23`

[Accueil](ANS_MOS_NOS_MigrationNOSversSMTT0_00_accueil.md)

# Correction de la correspondance NOS –> FHIR

## Résumé

L’étude de l’intégration des NOS dans le SMT, côté SMT, a montré un certain nombre d’erreurs dans la mise en correspondance des NOS en FHIR. Cette partie de l’étude ne s’intéresse qu’aux erreurs NOS –> FHIR et non aux évolutions pour la migration des NOS dans le SMT.

## Nom de la ressource FHIR

Existant : Ce nom comporte des caractères “_”

Exemple : `"name": "TRE_G00-Langue"`

**Correction : les caractères “_” étant interdits dans le nom d’une ressource Fhir, ils doivent être supprimés ou remplacés par “-“**

[Lien sur les règles de nommage NOS](ANS_MOS_NOS_MigrationNOSversSMTT0_51_NommageDesNOS)

## Display d’un codeConcept d’un codeSystem

Existant :

* La macro d’extraction des NOS –> DHIR met le libellé long dans l’attribut “Display” et renseigne les 2 autres libellés de la TRE dans des attributs Designation

Exemple d’une entrée de la TRE_G00-Langue:

`{ "code": "el", "display": "grec moderne (après 1453)", "designation": [ { "use": { "code": "LibelleCourt" }, "value": "grec moderne" }, { "use": { "code": "LibelleAdapte" }, "value": "grec moderne (après 1453)" } ],`

**Correction : C’est le libellé adapté de l’entrée d’une TRE qui doit être dans le champs Display d’une entrée du CodeSystem et non le libellé long.**

## Format de l’URL FHIR

Existant : Le format utilisé dans les NOS ne mentionne pas le type de ressource, à tort.

Exemple : `"url": "https://mos.esante.gouv.fr/NOS/TRE_G00-Langue/FHIR/TRE-G00-Langue",`

**Correction : Ajouter “CodeSystem” ou “ValueSet” ou “Map **

[Lien sur les règles de nommage NOS](ANS_MOS_NOS_MigrationNOSversSMTT0_51_NommageDesNOS)

## A compléter

| | | |
| :--- | :--- | :--- |
|  [<prev](NOS_MiseEnQualite_RepriseDesLibellesDesJDV.md) | [top](#top) |  [next>](tre.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

