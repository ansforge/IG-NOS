# ANS.FR.NOS\Accueil - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Accueil**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/nos/ImplementationGuide/ans.fr.nos | *Version*:1.5.0 |
| Active as of 2024-08 | *Computable Name*:NOS |

Contents:

* [Nomenclatures des objets de Santé](#intro)
* [Indicateur](#indicateur)
* [Un référentiel commun](#referentiel)
* [Des évolutions constantes et une publication mensuelle](#evolution)
* [Un avantage pour les acteurs de la e-santé](#avantage)

### Nomenclatures des objets de Santé

Les nomenclatures des objets de santé (NOS) sont indissociables du Modèle des Objets de Santé (MOS) et sont mises à disposition du secteur santé-social par l’agence du numérique en santé. Les NOS reposent sur un système de codification (code et libellé) des éléments structurés du MOS (catégorie d'établissement, profession, etc.). 

### Indicateur

Chaque mois, les indicateurs sont mis à jour comptabilisant le nombre de nomenclatures présentes : terminologie de référence, jeux de valeurs et tables d’association. Les NOS sont disponibles en plusieurs formats : PDF, CSV (.tabs), XML, SVS, XML/FHIR et JSON/FHIR. 

### Un référentiel commun

Les NOS sont découpées en trois familles : 
* **Les terminologies de référence (TRE)**sont des nomenclatures officielles créées et maintenues : 
* soit par l'agence du numérique en santé qui en est propriétaire. 
 Par exemple, la TRE_R87-TypeCarte est une nomenclature regroupant les différents types de cartes des professionnels (CPx) fournies par l’agence du numérique en santé ;
* soit par une organisation externe à l'agence du numérique en santé ; dans ce cas, l'agence du numérique en santé extrait la terminologie, la formate selon ses conventions de nommage et de structure, pour l'intégrer dans ses systèmes.
 
* **Les jeux de valeurs** **(JDV)** sont des nomenclatures constituées de codes extraits d’une ou plusieurs TRE. Un jeu de valeurs est créé à des fins applicatives. 
 Par exemple avec les JDV du répertoire opérationnel des ressources (ROR) ou bien du cadre d’interopérabilité des systèmes d’information de santé (CI-SIS).
* **Les tables d'association (ASS)** sont des tables assurant la correspondance entre les codes issus d'au moins deux TRE. 
 Par exemple, la codification des secteurs d'activité dans le répertoire ADELI est remplacée par une codification RPPS. Cette migration nécessite de créer une table associant les codes de secteurs d’activité ADELI à ceux des secteurs d’activité RPPS.
 Pour plus d'informations sur la constitution de ces nomenclatures, se reporter au document « Conventions de nommage et de structure des nomenclatures et des tables ». 

### Des évolutions constantes et une publication mensuelle

Les nomenclatures des objets de santé sont sujettes à des mises à jour continues pour suivre au mieux les évolutions des différents domaines. Ces mises à jour suivent un processus formalisé au sein de l’agence du numérique en santé et sont publiées mensuellement. Le document « Historique des modifications des NOS » recense toutes les mises à jour des NOS, triées par date de publication. 

| |
| :--- |
| ![](Process_1.png) |

 

### Un avantage pour les acteurs de la e-santé

Depuis sa publication en septembre 2013, la nomenclature des acteurs de santé (NAS) avait gardé un périmètre circonscrit aux acteurs de santé. Les NOS, remplacent la NAS et étendent le périmètre d'origine en couvrant désormais les nomenclatures associées aux : 

 
* attributs du modèle des objets de santé (MOS) dont les valeurs sont codifiées ;
* nomenclatures et tables des systèmes ou domaines sur lesquels l'agence du numérique en santé est amenée à intervenir, tels que : 
* le Répertoire Partagé des Professionnels de Santé (RPPS), pour les nomenclatures spécifiques à des objets de son périmètre ;
* le Répertoire Opérationnel des Ressources (ROR), avec toutes les nomenclatures relatives aux offres de soins ;
* le système d'information des Cartes de Professionnel de Santé (SI-CPS), concernant les nomenclatures spécifiques aux cartes CPx et aux certificats des infrastructures de gestion de clés de l'agence du numérique en santé ;
* le cadre d'interopérabilité des systèmes d'information de santé (CI-SIS) pour les nomenclatures créées pour les besoins des volets techniques.
 
 

Le recours aux NOS permet également aux acteurs de santé, consommateurs de données de: 

 
* connaitre l’historique des termes avec l’indication d’une date d’obsolescence lorsque le code n'est plus utilisé (la suppression des codes est interdite);
* s’accorder à tout environnement en proposant trois types de libellé : 
* Adapté, qui a comme vocation d’être le plus compréhensible pour un acteur humain ;
* Court, utilisable par les systèmes avec des problèmes de ressources ;
* Long, compatible avec les dispositifs mobiles.
 
 

| |
| :--- |
| ![](MicrosoftTeams-image.png) |

Pour nous écrire : [ANS-NOS-GESTION-DM@esante.gouv.fr](mailto:ANS-NOS-GESTION-DM@esante.gouv.fr)

*" Ce que l'on conçoit bien s'énonce clairement "
Nicolas Boileau*

| | | |
| :--- | :--- | :--- |
|  [<prev](toc.md) | [top](#top) |  [next>](nos.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

