# ANS.FR.NOS\A propos de ce guide - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **A propos de ce guide**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## A propos de ce guide

Cet Implementation Guide a été généré avec l’outil HL7 publisher développé par HL7. Il permet d’associer une documentation technique et une documentation narrative au sein d’un même site web :

* La documentation narrative se trouve dans les différentes pages de cette spécification naviguable à travers les boutons “prev”, “bottom”, “next” présents en haut et bas de page ou avec la barre de navigation.
* Une représentation graphique des profils spécifiés sous forme de [table logique](http://hl7.org/fhir/R4/formats.html#table) se trouve dans l’onglet Autres ressources > [artifacts](artifacts.md).

Cette nouvelle proposition de diffusion de spécifications se base sur les tendances internationales d’HL7 et utilise les outils open source [FSH](https://build.fhir.org/ig/HL7/fhir-shorthand/) et [IG Publisher](https://confluence.hl7.org/display/FHIR/IG+Publisher+Documentation). Exemples d’usage :

* L’IG [US core](https://www.hl7.org/fhir/us/core)
* L’IG [mcode](http://hl7.org/fhir/us/mcode)
* L’IG [CH core](http://build.fhir.org/ig/hl7ch/ch-core)
* L’IG [BE core](https://build.fhir.org/ig/hl7-be/core)

Une fois validé et publié sur le [FHIR Registry](https://registry.fhir.org/), ce guide pourra être utilisé comme héritage pour être surspécifié. Par exemple, il pourra être surspécifié et versionné pour créer une documentation applicative.

L’onglet de [téléchargement](downloads.md) vous permettra de télécharger :

* le package qui contient toutes les ressources de conformance (StructureDefinition, SearchParameter, …)
* L’ensemble de cette documentation pour consultation hors ligne.

Ce guide a été généré à partir de ce [repository GitHub](https://github.com/ansforge/FIG_ans-ig-PDSm), qui contient également l’historique des commits.

Liens utiles :

* [Wiki ANS sur les IGs](https://github.com/ansforge/FIG_ans-ig-sample/wiki) (en cours de construction)
* [Documentation IG Publisher](https://confluence.hl7.org/display/FHIR/IG+Publisher+Documentation)

| | | |
| :--- | :--- | :--- |
|  [<prev](downloads.md) | [top](#top) |  [next>](artifacts.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

