# ANS.FR.NOS\Présentation - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**NOS**](nos.md)
* **Présentation**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Présentation

`DRAFT au 21/08/23`

[Retour à la page d’accueil des NOS](ANS_MOS_NOS_MigrationNOSversSMTT0_00_accueil.md)

# Les Nomenclatures des Objets de Santé (NOS)

Les NOS de l’ANS reposent sur un système de codification (code et libellé) permettant de décrire des domaines de valeurs de certains attributs des classes du Modèle des Objets de Santé (MOS).

Suivant de près le périmètre du MOS, l’ensemble des NOS évolue au fil des projets pour prendre en compte le vocabulaire du secteur sanitaire, des spécificités du secteur médico-administratif, médico-social et social.

Les NOS sont de trois types :

* Les terminologies de référence (TRE), nomenclatures officielles créées et maintenues soit par : 
* l’ANS qui en est propriétaire ;
* une organisation externe à l’ANS.
 
* Les jeux de valeurs (JDV), nomenclatures constituées de codes extraits d’une ou plusieurs TRE.
* Les tables d’association (ASS), tables assurant la correspondance entre les codes issus d’au moins deux TRE/JDV.

Les NOS, référencées dans le MOS et dans les volets du CI-SIS, sont mises à disposition du public via le site de l’ANS à l’adresse https://mos.esante.gouv.fr/NOS/

# Le Serveur Multi Terminologies (SMT)

Le SMT de l’ANS est un espace d’hébergement et de gestion des terminologies de référence propres à l’ANS ou externes et offre :

* Un point d’entrée unique et institutionnel à destination des professionnels et du grand publique
* Plusieurs outils et services : 
* Un catalogue de terminologies standardisées s’appuyant sur les critères du web sémantique
* Une plateforme de formation dédiée à l’amélioration des connaissances autour des terminologies de santé
* L’actualité récente en matière de concepts et de termes spécifique au domaine de la santé
* La liste des API (interface de programmation interactive) disponibles pour communiquer avec le serveur
* Un SPARQL (SPARQL Protocol and RDF Query Language), langage informatique normalisé servant à rechercher les terminologies indexées dans le SMT
* Un service d’aide à la recherche des terminologies et des concepts s’y référant.
 

Le SMT est accessible via le site de l’ANS à l’adresse https://industriels.esante.gouv.fr/produits-et-services/smt-serveur-multi-terminologies

# Le guide d’implémentation des NOS

* La documentation des NOS est à présent disponible dans une version draft du Guide d’implémentation des NOS.
* Il est possible de télécharger les NOS dans les différents formats. Le format “pdf” sera bientôt disponible.

[Accès aux IG des NOS](https://ansforge.github.io/IG-NOS/ig/allNos2/)

[Accès au Github](https://github.com/ansforge/IG-fhir-partage-de-documents-de-sante)

| | | |
| :--- | :--- | :--- |
|  [<prev](nos.md) | [top](#top) |  [next>](NOS_MigrationNOSversSMTT0_10_QuestCeQuneTRE.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

