# ANS.FR.NOS\Artifacts Summary - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Artifacts Summary

Contents:

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

| | | |
| :--- | :--- | :--- |
|  [<prev](about.md) | [top](#top) |  next> |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

