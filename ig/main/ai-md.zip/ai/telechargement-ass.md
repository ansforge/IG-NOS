# ANS.FR.NOS\Association - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Association**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Association

Les tables d'association (ASS) sont des tables assurant la correspondance entre les codes issus d'au moins deux TRE. Par exemple, la codification des secteurs d'activité dans le répertoire ADELI est remplacée par une codification RPPS. Cette migration nécessite de créer une table associant les codes de secteurs d’activité ADELI à ceux des secteurs d’activité RPPS.

* [Ensemble des associations](ass.md)
* [Téléchargement](#)

 Ensemble des associations à télécharger 

| | |
| :--- | :--- |
| [csv (ZIP)](NOS/NOS-ass-tabs.zip) | Au format csv |
| [Pdf (ZIP)](NOS/NOS-ass-pdf.zip) | Au format PDF |
| [fhir (ZIP)](NOS/NOS-ass-fhir-json.zip) | Au format Fhir Json |
| [fhir (ZIP)](NOS/NOS-ass-fhir-xml.zip) | Au format Fhir Xml |

| | | |
| :--- | :--- | :--- |
|  [<prev](namingSystem.md) | [top](#top) |  [next>](autres_ressources.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

