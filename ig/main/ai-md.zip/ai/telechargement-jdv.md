# ANS.FR.NOS\Jeux de valeurs - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Jeux de valeurs**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Jeux de valeurs

Les jeux de valeurs (JDV) sont des nomenclatures constituées de codes extraits d’une ou plusieurs TRE. Un jeu de valeurs est créé à des fins applicatives. Par exemple avec les JDV du répertoire opérationnel des ressources (ROR) ou bien du cadre d’interopérabilité des systèmes d’information de santé (CI-SIS).

* [Ensemble des JDV](jdv.md)
* [Ensemble des JDV (par projet)](jdv-nos.md)
* [Téléchargement](#)

 Ensemble des JDV à télécharger 

| | |
| :--- | :--- |
| [csv (ZIP)](NOS/NOS-jdv-tabs.zip) | Au format csv |
| [Pdf (ZIP)](NOS/NOS-jdv-pdf.zip) | Au format PDF |
| [svs (ZIP)](NOS/NOS-jdv-svs.zip) | Au format svs (Sharing Value Sets) |
| [fhir (ZIP)](NOS/NOS-jdv-fhir-json.zip) | Au format Fhir Json |
| [fhir (ZIP)](NOS/NOS-jdv-fhir-xml.zip) | Au format Fhir Xml |

| | | |
| :--- | :--- | :--- |
|  [<prev](jdv.md) | [top](#top) |  [next>](ass.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

