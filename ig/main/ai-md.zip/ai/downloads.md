# ANS.FR.NOS\Téléchargements et usages - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Autres Ressources**](autres_ressources.md)
* **Téléchargements et usages**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Téléchargements et usages

Téléchargements et usage

L’implementation guide contient un package [téléchargeable ici](package.tgz) permettant de valider les instances par rapport aux profils qu’il contient.

Pour cela, il suffit de télécharger le [package.tgz](package.tgz) et l’importer dans un serveur, par exemple sur hapi en suivant ce [script python](https://github.com/nmdp-bioinformatics/igloader) open source.

Vous pourrez ensuite utiliser l’opération [$validate](https://www.hl7.org/fhir/resource-operation-validate.html) pour valider les instances de ressource contre un profil issu de cette spécification.

Ensemble des ressources téléchargeables :

* [L’ensemble de la specification (zip)](full-ig.zip)
* [Package (tgz)](package.tgz)
* [JSON Définitions (zip)](definitions.json.zip)
* [JSON Exemples (zip)](examples.json.zip)
* [XML Definitions (zip)](definitions.xml.zip)
* [XML Exemples (zip)](examples.ttl.zip)
* [Turtle Définitions](definitions.ttl.zip)

| | | |
| :--- | :--- | :--- |
|  [<prev](securite.md) | [top](#top) |  [next>](about.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

