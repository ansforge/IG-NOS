# ANS.FR.NOS\NOS - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **NOS**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## NOS

* [Migartion du NOS dans le cadre de la mise à diposition d’un serveur de terminologie](#migartion-du-nos-dans-le-cadre-de-la-mise-à-diposition-dun-serveur-de-terminologie)
* [Exemple des modifications](#exemple-des-modifications)

### Migartion du NOS dans le cadre de la mise à diposition d’un serveur de terminologie

Cette page décrit les modifications apportées sur l’existant afin d’avoir une intégration compléte vers serveur FHIR® utilisé pour gérer les Terminologies, les jeux de valeurs et les alignements de jeux de valeurs dans le domaine de la santé.

#### Règle 1

#### Règle 2

#### Règle 3

### Exemple des modifications

#### ValueSet

`Avant`

`Aprés`

#### CodeSystem

`Avant`

`Aprés`

| | | |
| :--- | :--- | :--- |
|  [<prev](index.md) | [top](#top) |  [next>](NOS_MigrationNOSversSMTT0_01_PresDesNOSetSMT.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

