# ANS.FR.NOS\Publication - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**NOS**](nos.md)
* **Publication**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Publication

* [Mise à disposition des NOS](#mise-à-disposition-des-nos) 
* [Rappel de l’existant](#rappel-de-lexistant)
* [Nouvelles règles](#nouvelles-règles)
 

`DRAFT au 21/08/23`

[Retour à la page d’accueil des NOS](ANS_MOS_NOS_MigrationNOSversSMTT0_00_accueil.md)

# Mise à disposition des NOS

### Rappel de l’existant

Les NOS sont disponibles sur le site de l’ANS, dans la partie Interopérabilité avec le MOS. Il est possible de les télécharger sous différents formats et sont également visualisables sur le serveur https://mos.esante.gouv.fr/NOS/.

Les NOS sont sujettes à des mises à jour continues pour suivre au mieux les évolutions des différents domaines. Ces mises à jour suivent un processus formalisé au sein de l’ANS et sont publiées mensuellement.

L’historique également disponible sur le site permet de connaitre l’ensemble des modifications apportées aux NOS par date de publication.

### Nouvelles règles

Les NOS sont à présent disponibles sur l’IG xxx

| | | |
| :--- | :--- | :--- |
|  [<prev](NOS_MigrationNOSversSMTT0_23_CycleDeVieDesJDV.md) | [top](#top) |  [next>](NOS_MigrationNOSversSMTT0_51_NommageDesNOS.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

