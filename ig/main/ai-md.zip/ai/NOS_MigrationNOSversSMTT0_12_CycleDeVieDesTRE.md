# ANS.FR.NOS\TRE (Cycle de vie) - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**NOS**](nos.md)
* **TRE (Cycle de vie)**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## TRE (Cycle de vie)

* [Impacts sur le cycle de vie des TRE](#impacts-sur-le-cycle-de-vie-des-tre) 
* [Résumé](#résumé)
* [Cycle de vie des nomenclatures NOS de type TRE](#cycle-de-vie-des-nomenclatures-nos-de-type-tre) 
* [a) Opérations sur une TRE - Rappel de l’existant](#a-opérations-sur-une-tre---rappel-de-lexistant)
* [b) Opérations sur une TRE - Nouvelles règles](#b-opérations-sur-une-tre---nouvelles-règles)
 
 

`DRAFT au 21/08/23`

[Accueil](ANS_MOS_NOS_MigrationNOSversSMTT0_00_accueil.md)    

# Impacts sur le cycle de vie des TRE

## Résumé

* Les états “Active” et “obsolète” d’une TRE ou d’une entrée d’une TRE existent toujours.
* Dans le SMT, l’état “obsolète” est nuancé : il est d’abord “Depreciated” puis passe au bout d’un certain temps à “retired”.
* Il n’est plus possible de réactiver ni une TRE ni une entrée d’une TRE une fois que la TRE ou que l’entrée de la TRE est passée à l’état “ Depreciated”.
* Toujours pas de motif de changement d’état.
* Toujours pas de lien entre une entrée “A” d’une TRE qui devient obsolète pour devenir une entrée “B”. **(Mais cette fonction était surtout utile pour interdire la réactivation de l’entrée A si B était encore active).**

## Cycle de vie des nomenclatures NOS de type TRE

### a) Opérations sur une TRE - Rappel de l’existant

* Créer une TRE (nom, OID, URL, description, date de création, date de fin de validité, date de modification)
* modifier la TRE (description, date de modification)
* Désactiver la TRE (date fin de validité, date de modification)
* Réactiver la TRE (date fin de validité, date de modification)
* Créer une entrée de la TRE (code, libellé long, libellé court, libellé adapté)
* Désativer une entrée de la TRE (code, date de fin de validité, date de modification)
* Modifier une entrée de la TRE (code, type de libellé, date de modification)
* Réactiver un code d’une TRE (code, date de fin de validité, date de modification)

**Cycle de vie d'une nomenclature TRE - Existant**
### b) Opérations sur une TRE - Nouvelles règles

* Les TRE Externes présentes dans le SMT ne peuvent plus être créées
* Créer une TRE (code system, OID, URI, description, status, version)
* Modifier la TRE (description, date de modification)
* Désactiver une TRE (code system, status)
* Créer une entrée de la TRE (code concept, status, display, designation1, designation2, traduction)
* Desativer une entrée de la TRE (code concept, statut)
* Modifier une entrée de la TRE (code concept, display, designation 1 , désignation 2, traduction)

**Cycle de vie d'une nomenclature TRE - Dans le SMT**

| | | |
| :--- | :--- | :--- |
|  [<prev](NOS_MigrationNOSversSMTT0_11_ProprietesDesTRE.md) | [top](#top) |  [next>](NOS_MigrationNOSversSMTT0_20_QuestCeQunJDV.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

