# ANS.FR.NOS\Terminologies - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Terminologies**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## Terminologies

Les terminologies sont des nomenclatures officielles créées et maintenues :

- soit par l'agence du numérique en santé qui en est propriétaire. Par exemple, la TRE_R87-TypeCarte est une nomenclature regroupant les différents types de cartes des professionnels (CPx) fournies par l’agence du numérique en santé ;

- soit par une organisation externe à l'agence du numérique en santé ; dans ce cas, l'agence du numérique en santé extrait la terminologie, la formate selon ses conventions de nommage et de structure, pour l'intégrer dans ses systèmes.

* [Ensemble des TRE](#)
* [Téléchargement](telechargement-tre.md)

 Liste des TRE 

| | | |
| :--- | :--- | :--- |
|  [<prev](NOS_MiseEnQualiteCorrectionDuMappingNOSversFhir.md) | [top](#top) |  [next>](telechargement-tre.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

