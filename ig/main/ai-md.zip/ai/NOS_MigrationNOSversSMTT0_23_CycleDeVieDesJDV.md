# ANS.FR.NOS\JDV (Cycle de vie) - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**NOS**](nos.md)
* **JDV (Cycle de vie)**

Nomenclatures des objets de santé (NOS) - Local Development build (v1.5.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/nos/history.html)

## JDV (Cycle de vie)

* [Cycle de vie des nomenclatures NOS de type JDV](#cycle-de-vie-des-nomenclatures-nos-de-type-jdv) 
* [a) Rappel de l’existant](#a--rappel-de-lexistant) 
* [Opérations sur un JDV](#opérations-sur-un-jdv)
 
* [b) Nouvelles règles](#b-nouvelles-règles) 
* [Opérations sur un JDV :](#opérations-sur-un-jdv-)
 
* [c) IMPACTS](#c-impacts)
* [d) Principe de migration](#d-principe-de-migration)
* [e) Documents de référence](#e-documents-de-référence)
 

`DRAFT au 21/08/23`

[Retour à la page d’accueil des NOS](ANS_MOS_NOS_MigrationNOSversSMTT0_00_accueil.md)

# Cycle de vie des nomenclatures NOS de type JDV

## a) Rappel de l’existant

### Opérations sur un JDV

* Créer un JDV (nom, OID, URL, description, date de création, date de fin de validité, date de modification)
* Modifier le JDV (description, date de modification)
* Désactiver le JDV (date fin de validité, date de modification)
* Réactiver le JDV (date fin de validité, date de modification)
* Ajouter une entrée dans le JDV (ref TRE, code , libellé retenu)
* Retirer une entrée du JDV (ref TRE, code)

**Cycle de vie d'une nomenclature JDV - Existant**
## b) Nouvelles règles

### Opérations sur un JDV :

* Créer un JDV (nom, OID, URL, description, date de création, date de fin de validité, date de modification)
* Possibilité de créer un JDV à partir d’une règle
* Modifier le JDV (description, date de modification)
* Désactiver le JDV (date fin de validité, date de modification)
* Ajouter une entrée dans le JDV (ref TRE, code , libellé retenu)
* Retirer une entrée du JDV (ref TRE, code)

**Cycle de vie d'un jeu de valeurs - Dans le SMT**
## c) IMPACTS

* Il n’est plus possible de réactiver un JDV
* Nouvelle Possibilité de créer un JDV à partir d’une règle 
* exemple de règle : Tous les codes actifs d’une TRE; tous les codes d’une TRE; règle métier pour des JDV fonctionnels
 
* Le libellé généré dans le JDV sera toujours le “Display” du code de la TRE

## d) Principe de migration

RAS

## e) Documents de référence

* Voir [la convention de nommage des NOS](https://esante.gouv.fr/sites/default/files/media_entity/documents/NOS_ConventionNOS_V2.0.pdf).
* Voir [la correspondance RessourcesFhir Et NOS existant](https://esante.gouv.fr/sites/default/files/media_entity/documents/Correspondances%20RessourcesFHIR-NOS_0.pdf)

| | | |
| :--- | :--- | :--- |
|  [<prev](NOS_MigrationNOSversSMTT0_20_QuestCeQunJDV.md) | [top](#top) |  [next>](NOS_MigrationNOSversSMTT0_50_Publication.md) |

 IG © 2020+ [ANS](https://esante.gouv.fr). Package ans.fr.nos#1.5.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://interop.esante.gouv.fr/ig/nos/history.html) | [New Issue](https://github.com/ansforge/IG-NOS/issues/new)  

